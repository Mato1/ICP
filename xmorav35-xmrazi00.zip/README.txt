Aplikace BlockEditor

Projekt do ICP

Autori:
Matej Mrázik (xmrazi00)
Libor Moravčík (xmorav35)

Zadanie projektu:

Navrhnúť a naimplementovať aplikáciu pre návrh a editáciu blokových schémat.

Základn0 dovednosti projektu:

Spustiteľnosť   
Vytváranie a editovanie schémat    
Ukládanie a načítanie   
Generovanie dokumentace 
Dokumentácia v kóde  
Grafické rozhranie 
Detekovanie cyklov
Krokovanie


Spustenie aplikácie:

./blockeditor

Kompilácia aplikácie:

make, make doxygen, make run, make clean
